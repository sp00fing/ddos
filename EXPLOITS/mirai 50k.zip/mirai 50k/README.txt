chmod 777 *
chmod 777 z

./z config